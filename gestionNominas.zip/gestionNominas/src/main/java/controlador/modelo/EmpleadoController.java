package controlador.modelo;

import java.sql.ResultSet;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import controlador.database.DBconnection;
import modelo.Empleado;

public class EmpleadoController implements IEmpleadoController {

	@Override
	public boolean aniadirEmpleado(Empleado oEmpleado1) {

		boolean bExito = false;

		String sNombre = oEmpleado1.getsNombre();
		String sDni = oEmpleado1.getsDni();
		String sLetra = oEmpleado1.getsLetra();
		byte bCategoria = oEmpleado1.getbCategoria();
		byte bAnio = oEmpleado1.getbAnios();

		String sql = "SELECT COUNT(*) FROM EMPLEADO WHERE DNI = '" + sDni + "'";

		if (DBconnection.executeCount(sql) == 0) {

			String sql2 = "INSERT INTO EMPLEADO VALUES ('" + sNombre + "'," + bCategoria + "," + bAnio + ",'" + sDni
					+ "','" + sLetra + "')";

			DBconnection.executeUpdate(sql2);

			String sqlSalary = "INSERT INTO NOMINA VALUES (" + getSalarioDB(sDni) + ",'" + sDni + "');";
			DBconnection.executeUpdate(sqlSalary);
			bExito = true;

		}
		return bExito;

	}

	@Override
	public List<Empleado> mostrarEmpleados() {

		String sLetra = null;
		String sNombre = null;
		String sDni = null;
		byte bAnios = 0;
		byte bCategoria = 0;
		List<Empleado> list = null;

		String sql2 = "SELECT * FROM EMPLEADO;";

		try {
			list = new ArrayList<Empleado>();
			Statement statement = DBconnection.getConnection().createStatement();
			ResultSet resultSet = statement.executeQuery(sql2);
			while (resultSet.next()) {

				sNombre = resultSet.getString("nombre");
				sDni = resultSet.getString("dni");
				sLetra = resultSet.getString("sexo");
				int iAnios = resultSet.getInt("anio");
				int iCategoria = resultSet.getInt("categoria");

				bAnios = (byte) iAnios;
				bCategoria = (byte) iCategoria;

				Empleado oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
				list.add(oEmpleado);

			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return list;

	}

	@Override
	public List<Empleado> buscarEmpleadoPorDni(Empleado oEmpleado) {

		String sLetra = null;
		String sNombre = null;
		String sDni = null;
		byte bAnios = 0;
		byte bCategoria = 0;
		List<Empleado> list = null;
		
		sDni = oEmpleado.getsDni();

		String sql = "SELECT * FROM EMPLEADO WHERE DNI = '" + sDni + "';";

		try {
			list = new ArrayList<Empleado>();
			Statement statement = DBconnection.getConnection().createStatement();
			ResultSet resultSet = statement.executeQuery(sql);
			while (resultSet.next()) {

				sNombre = resultSet.getString("nombre");
				sDni = resultSet.getString("dni");
				sLetra = resultSet.getString("sexo");
				int iAnios = resultSet.getInt("anio");
				int iCategoria = resultSet.getInt("categoria");

				bAnios = (byte) iAnios;
				bCategoria = (byte) iCategoria;

				Empleado oEmpleado1 = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
				list.add(oEmpleado1);

			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return list;

	}

	@Override
	public boolean modificarEmpleado(Empleado oEmpleado, Empleado oEmpleadoModificado) {

		boolean bExito = false;

		String sDniBuscador = oEmpleado.getsDni();

		String sql = "SELECT COUNT(*) FROM EMPLEADO WHERE DNI = '" + sDniBuscador + "' ";

		if (DBconnection.executeCount(sql) != 0) {

			String sNombre = oEmpleadoModificado.getsNombre();
			String sLetra = oEmpleadoModificado.getsLetra();
			String sDni = oEmpleadoModificado.getsDni();
			byte bCategoria = oEmpleadoModificado.getbCategoria();
			byte bAnios = oEmpleadoModificado.getbAnios();

			String sql2 = "INSERT INTO EMPLEADO VALUES ('" + sNombre + "'," + bCategoria + "," + bAnios + ",'" + sDni
					+ "','" + sLetra + "')";

			DBconnection.executeUpdate(sql2);
			bExito = true;

		}
		return bExito;

	}

	@Override
	public void modificarSalarios() {

		String sql = "UPDATE empleado SET anio = (SELECT anio FROM empleado)+1;";

		DBconnection.executeUpdate(sql);
	}

	@Override
	public List<Empleado> buscarEmpleadoPorNombre(Empleado oEmpleado) {

		String sLetra = null;
		String sNombre = null;
		String sDni = null;
		byte bAnios = 0;
		byte bCategoria = 0;
		List<Empleado> list = null;
		sNombre = oEmpleado.getsNombre();

		String sql = "SELECT * FROM EMPLEADO WHERE NOMBRE = '" + sNombre + "'";

		try {
			list = new ArrayList<Empleado>();
			Statement statement = DBconnection.getConnection().createStatement();
			ResultSet resultSet = statement.executeQuery(sql);
			while (resultSet.next()) {

				sNombre = resultSet.getString("nombre");
				sDni = resultSet.getString("dni");
				sLetra = resultSet.getString("sexo");
				int iAnios = resultSet.getInt("anio");
				int iCategoria = resultSet.getInt("categoria");

				bAnios = (byte) iAnios;
				bCategoria = (byte) iCategoria;

				Empleado oEmpleado1 = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
				list.add(oEmpleado1);

			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return list;

	}

	@Override
	public List<Empleado> buscarEmpleadoPorSexo(Empleado oEmpleado) {

		String sNombre = null;
		String sDni = null;
		byte bAnios = 0;
		byte bCategoria = 0;
		String sLetra = null;
		sLetra = oEmpleado.getsLetra();
		List<Empleado> list = null;

		String sql2 = "SELECT * FROM EMPLEADO WHERE SEXO = '" + sLetra + "'";

		try {
			list = new ArrayList<Empleado>();
			Statement statement = DBconnection.getConnection().createStatement();
			ResultSet resultSet = statement.executeQuery(sql2);
			while (resultSet.next()) {

				sNombre = resultSet.getString("nombre");
				sDni = resultSet.getString("dni");
				sLetra = resultSet.getString("sexo");
				int iAnios = resultSet.getInt("anio");
				int iCategoria = resultSet.getInt("categoria");

				bAnios = (byte) iAnios;
				bCategoria = (byte) iCategoria;

				Empleado oEmpleado1 = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
				list.add(oEmpleado1);

			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return list;

	}

	@Override
	public List<Empleado> buscarEmpleadoPorCategoria(Empleado oEmpleado) {

		String sNombre = null;
		String sDni = null;
		byte bAnios = 0;
		byte bCategoria = 0;
		String sLetra = null;
		bCategoria = oEmpleado.getbCategoria();
		List<Empleado> list = null;

		String sql2 = "SELECT * FROM EMPLEADO WHERE CATEGORIA = '" + bCategoria + "'";

		try {
			list = new ArrayList<Empleado>();
			Statement statement = DBconnection.getConnection().createStatement();
			ResultSet resultSet = statement.executeQuery(sql2);
			while (resultSet.next()) {

				sNombre = resultSet.getString("nombre");
				sDni = resultSet.getString("dni");
				sLetra = resultSet.getString("sexo");
				int iAnios = resultSet.getInt("anio");
				int iCategoria = resultSet.getInt("categoria");

				bAnios = (byte) iAnios;
				bCategoria = (byte) iCategoria;

				Empleado oEmpleado1 = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
				list.add(oEmpleado1);

			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return list;

	}

	@Override
	public List<Empleado> buscarEmpleadoPorAnios(Empleado oEmpleado) {

		String sNombre = null;
		String sDni = null;
		byte bAnios = 0;
		byte bCategoria = 0;
		String sLetra = null;
		bAnios = oEmpleado.getbAnios();
		List<Empleado> list = null;

		String sql2 = "SELECT * FROM EMPLEADO WHERE ANIO = '" + bAnios + "'";

		try {
			list = new ArrayList<Empleado>();
			Statement statement = DBconnection.getConnection().createStatement();
			ResultSet resultSet = statement.executeQuery(sql2);
			while (resultSet.next()) {

				sNombre = resultSet.getString("nombre");
				sDni = resultSet.getString("dni");
				sLetra = resultSet.getString("sexo");
				int iAnios = resultSet.getInt("anio");
				int iCategoria = resultSet.getInt("categoria");

				bAnios = (byte) iAnios;
				bCategoria = (byte) iCategoria;

				Empleado oEmpleado1 = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
				list.add(oEmpleado1);

			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return list;

	}

	@Override
	public boolean modificarSalario(Empleado oEmpleado, Empleado oEmpleadoEditado) {

		boolean bExito = false;

		String sDniBuscador = oEmpleado.getsDni();

		String sql = "SELECT COUNT(*) FROM EMPLEADO WHERE DNI = '" + sDniBuscador + "'";

		if (DBconnection.executeCount(sql) != 0) {

		}
		return bExito;

	}

	public float getSalarioDB(String sDni) {
		float fResultado = 0;
		String sql = "SELECT SALARIO FROM NOMINA WHERE DNI = '" + sDni + "';";
		try {
			Statement statement = DBconnection.getConnection().createStatement();
			ResultSet resultSet = statement.executeQuery(sql);

			while (resultSet.next()) {

				float fSalario = resultSet.getFloat("salario");

				fResultado = fSalario;

			}
			resultSet.close();
			statement.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return fResultado;
	}

}
