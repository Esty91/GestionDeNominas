package controlador.database;

import controlador.modelo.EmpleadoController;

public class GeneralController implements IGeneralController {

	private DBconnection conexionDB;
	private EmpleadoController empleadoController;

	public GeneralController(String sDatabase) {

		this.conexionDB = new DBconnection(sDatabase);
		this.empleadoController = new EmpleadoController();

	}

	@Override
	public DBconnection getConexionDB() {
		return this.conexionDB;
	}

	
	@Override
	public EmpleadoController getEmpleadoController() {
		return this.empleadoController;
	}

}


