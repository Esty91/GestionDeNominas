package controlador.database;

import controlador.modelo.EmpleadoController;

public interface IGeneralController {

	public DBconnection getConexionDB();

	public EmpleadoController getEmpleadoController();

}