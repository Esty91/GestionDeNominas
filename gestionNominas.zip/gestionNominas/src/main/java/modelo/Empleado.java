package modelo;

public class Empleado extends Persona implements IEmpleado{

	private byte bCategoria;
	public byte bAnios;

	public Empleado(String sNombre, String sDni, String sLetra) {
		super(sNombre, sDni, sLetra);
		this.bCategoria = MIN_CATEGORIA;
		this.bAnios = SIN_EXP;
	}
	
	
	public Empleado(String sNombre, String sDni, String sLetra, byte bAnios, byte bCategoria) {
		super(sNombre, sDni, sLetra);
		setbCategoria(bCategoria);
		setbAnios(bAnios);
	}

	public Empleado(String sDni) {
		super(sDni);
	}
	
	
	@Override
	public byte getbCategoria() {
		return this.bCategoria;
	}

	
	@Override
	public boolean setbCategoria(byte bCategoria) {
		boolean bExito = false;
		if (bCategoria >= MIN_CATEGORIA && bCategoria <= MAX_CATEGORIA) {

			this.bCategoria = bCategoria;
			bExito = true;

		} else {
			this.bCategoria = -1;
		}
		return bExito;

	}


	@Override
	public byte getbAnios() {
		return this.bAnios;
	}

	
	@Override
	public void setbAnios(byte bAnios) {

		if (bAnios >= MIN_ANIOS && bCategoria <= MAX_ANIOS) {

			this.bAnios = bAnios;

		} else {
			this.bAnios = -1;
		}

	}

	
	@Override
	public boolean incrAnyo() {
		boolean bValido = false;

		if (this.bAnios >= MIN_ANIOS && this.bAnios < MAX_ANIOS) {
			this.bAnios = (byte) (this.bAnios + MIN_ANIOS);
			bValido = true;
		}

		return bValido;
	}

	
	@Override
	public String toString() {

		return "##############################################################" + "\n  --Empleado: \n"
				+ super.toString()
				//
				+ "\n  Sexo: " + super.sLetra
				//
				+ "\n  Categoria: " + this.bCategoria
				//
				+ "\n  Anios trabajados: " + this.bAnios;
	}

	@Override
	public boolean validaEmpleado(Empleado oEmpleado) {
		boolean bValido = false;
		if (super.sNombre != null && super.sDni != null && super.sLetra != null && this.bCategoria != -1) {
			bValido = true;
		}
		return bValido;

	}

}
