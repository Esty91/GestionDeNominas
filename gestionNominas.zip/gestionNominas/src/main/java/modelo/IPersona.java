package modelo;

public interface IPersona {

	public String getsNombre();

	public void setsNombre(String sNombre);

	public String getsDni();

	public void setsDni(String sDni);

	public String getsLetra();

	public void setcLetra(String sLetra);

	public String toString();
	
	
	public static final int MIN_NOMBRE = 3;
	public static final int MAX_NOMBRE = 30;
}
