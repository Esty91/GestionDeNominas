package modelo;

public interface INomina {

	public static final int MIN_STRING = 2;
	public static final int MAX__NOMBRE = 30;

	
	public static final int SALARIO_BASE[] = { 50000, 70000, 90000, 110000, 130000, 150000, 170000, 190000, 210000,
			230000 };

	public static final byte MIN_CATEGORIA = 1;
	public static final byte MAX_CATEGORIA = 10;
	public static final byte MIN_ANIOS = 1;
	public static final byte MAX_ANIOS = 50;
	public static final byte SIN_EXP = 0;
	public static final byte ANIO_MAS_UNO = 1;
	public static final short INCENTIVO_ANIO = 5000;
}
