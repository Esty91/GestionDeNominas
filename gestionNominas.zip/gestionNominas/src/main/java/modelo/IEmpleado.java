package modelo;

public interface IEmpleado {

	public static final byte MIN_CATEGORIA = 1;
	public static final byte SIN_EXP = 0;
	public static final byte MAX_CATEGORIA = 10;
	public static final byte MIN_ANIOS = 0;
	public static final byte MAX_ANIOS = 50;
	
	public byte getbCategoria();

	public boolean setbCategoria(byte bCategoria);

	public byte getbAnios();

	public void setbAnios(byte bAnios);

	public boolean incrAnyo();

	public String toString();

	public boolean validaEmpleado(Empleado oEmpleado);

}
