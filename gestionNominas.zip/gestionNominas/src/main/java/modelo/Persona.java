package modelo;

public class Persona implements IPersona{


	public String sNombre;
	public String sDni;
	public String sLetra;

	
	public Persona(String sNombre, String sDni, String sLetra) {

		setsNombre(sNombre);
		setsDni(sDni);
		setcLetra(sLetra);

	}

	
	public Persona(String sNombre, String sLetra) {

		setsNombre(sNombre);
		setcLetra(sLetra);
	}
	
	public Persona(String sDni) {
		setsDni(sDni);
	}

	
	@Override
	public String getsNombre() {
		return this.sNombre;
	}

	
	@Override
	public void setsNombre(String sNombre) {
		if (sNombre != null && sNombre.length() >= MIN_NOMBRE && sNombre.length() <= MAX_NOMBRE) {
			this.sNombre = sNombre;
		} else {
			this.sNombre = null;
		}
	}

	
	@Override
	public String getsDni() {
		return this.sDni;
	}

	
	@Override
	public void setsDni(String sDni) {
		if (sDni != null && sDni.length() == 9) {
			this.sDni = sDni;
		} else {
			this.sDni = null;
		}

	}

	
	

	
	@Override
	public String toString() {
		return "  --Nombre: " + this.sNombre + "  --Dni: " + this.sDni;
	}


	@Override
	public String getsLetra() {
		return this.sLetra;
	}


	@Override
	public void setcLetra(String sLetra) {
		this.sLetra = sLetra;
		
	}

	

}


