package Servlet;

import java.io.IOException;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Empleado;
import vista.Principal;

/**
 * Servlet implementation class ServletController
 */

public class ServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);

		String sOpcion = request.getParameter("Opcion");
		String sOpcion1 = request.getParameter("Opcion1");

		if (sOpcion.equals("mostrarDatos")) {

			List<Empleado> list = Principal.generalController.getEmpleadoController().mostrarEmpleados();
			request.setAttribute("listaEmpleados", list);

			RequestDispatcher dispatcher = request.getRequestDispatcher("listaEmpleados.jsp");
			dispatcher.forward(request, response);

		} else if (sOpcion.equals("modificarDatos")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("modificarDatos.jsp");
			dispatcher.forward(request, response);
		} else if (sOpcion.equals("seleccionDatosModificar")) {

			if (sOpcion1.equals("nombre")) {
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("buscarPorNombre.jsp");
				requestDispatcher.forward(request, response);
			} else if (sOpcion1.equals("dni")) {
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("buscarPorDni.jsp");
				requestDispatcher.forward(request, response);
			} else if (sOpcion1.equals("sexo")) {
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("buscarPorSexo.jsp");
				requestDispatcher.forward(request, response);
			} else if (sOpcion1.equals("categoria")) {
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("buscarPorCategoria.jsp");
				requestDispatcher.forward(request, response);
			} else if (sOpcion1.equals("aniosTrabajados")) {
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("buscarPorAnios.jsp");
				requestDispatcher.forward(request, response);
			} else if (sOpcion1.equals("volver")) {
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("index.jsp");
				requestDispatcher.forward(request, response);
			} else if (sOpcion1.equals("buscarEmpleadoPorNombre")) {
				buscarPorNombre(request, response);
			} else if (sOpcion1.equals("buscarEmpleadoPorDni")) {
				buscarPorDni(request, response);
			} else if (sOpcion1.equals("buscarEmpleadoPorSexo")) {
				buscarPorSexo(request, response);
			} else if (sOpcion1.equals("buscarEmpleadoPorCategoria")) {
				buscarPorCategoria(request, response);
			} else if (sOpcion1.equals("buscarEmpleadoPorAnios")) {
				buscarPorAnios(request, response);
			}
		}else if (sOpcion.equals("mostrarSalario")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("mostrarSalario.jsp");
			dispatcher.forward(request, response);
		}else if (sOpcion.equals("seleccionMostrarSalario")) {
			mostrarSalario(request, response);
		}
		}

	public void mostrarSalario(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String sDni = request.getParameter("DNI");
		String sNombre = null;
		String sLetra = null;
		byte bAnios = 0;
		byte bCategoria = 0;
		
		
		float fSalario = Principal.generalController.getEmpleadoController().getSalarioDB(sDni);
		Empleado oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
		List<Empleado> list = Principal.generalController.getEmpleadoController().buscarEmpleadoPorDni(oEmpleado);
		
		request.setAttribute("mostrarSalario",fSalario);
		request.setAttribute("mostrarEmpleado", list);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("tablaSalario1E.jsp");
		requestDispatcher.forward(request, response);
	}

	public void buscarPorAnios(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String bAnios = request.getParameter("anios");
		byte bAnios1 = Byte.parseByte(bAnios);
		String sNombre = null;
		String sDni = null;
		String sLetra = null;
		Byte bCategoria= 0;


		
		Empleado oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios1, bCategoria);
		List<Empleado> list = Principal.generalController.getEmpleadoController().buscarEmpleadoPorAnios(oEmpleado);

		request.setAttribute("empleadoPorAnios", list);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("empleadoPorAnios.jsp");
		requestDispatcher.forward(request, response);
	}

	public void buscarPorCategoria(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String bCategoria = request.getParameter("categoria");
		byte bCategoria1 = Byte.parseByte(bCategoria);
		String sNombre = null;
		String sDni = null;
		String sLetra = null;
		byte bAnios = 0;

		
		Empleado oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria1);
		List<Empleado> list = Principal.generalController.getEmpleadoController().buscarEmpleadoPorCategoria(oEmpleado);

		request.setAttribute("empleadoPorCategoria", list);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("empleadoPorCategoria.jsp");
		requestDispatcher.forward(request, response);
	}

	public void buscarPorSexo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String sLetra = request.getParameter("sexo");
		String sDni = null;
		String sNombre = null;
		byte bAnios = 0;
		byte bCategoria = 0;

		Empleado oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
		List<Empleado> list = Principal.generalController.getEmpleadoController().buscarEmpleadoPorSexo(oEmpleado);

		request.setAttribute("empleadoPorSexo", list);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("empleadoPorSexo.jsp");
		requestDispatcher.forward(request, response);
	}

	public void buscarPorDni(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String sDni = request.getParameter("DNI");
		String sNombre = null;
		String sLetra = null;
		byte bAnios = 0;
		byte bCategoria = 0;
		
		Empleado oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
		List<Empleado> list = Principal.generalController.getEmpleadoController().buscarEmpleadoPorDni(oEmpleado);
		
		request.setAttribute("empleadoPorDni",list);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("empleadoPorDni.jsp");
		requestDispatcher.forward(request, response);
	}

	public void buscarPorNombre(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String sNombre = request.getParameter("nombre");
		String sDni = null;
		String sLetra = null;
		byte bAnios = 0;
		byte bCategoria = 0;

		Empleado oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
		List<Empleado> list = Principal.generalController.getEmpleadoController().buscarEmpleadoPorNombre(oEmpleado);

		request.setAttribute("empleadoPorNombre", list);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("empleadoPorNombre.jsp");
		requestDispatcher.forward(request, response);
	}

		/*
		 * String sId= request.getParameter("id"); if (sId.equals("nombre")) {
		 * doGet(request, response); RequestDispatcher requestDispatcher1 =
		 * request.getRequestDispatcher("buscarPorNombre.jsp");
		 * requestDispatcher1.forward(request, response); String sNombre =
		 * request.getParameter("nombre"); String sDni = null; String sLetra = null;
		 * byte bAnios = 0; byte bCategoria = 0;
		 * 
		 * Empleado oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
		 * List<Empleado> list = Principal.generalController.getEmpleadoController()
		 * .buscarEmpleadoPorNombre(oEmpleado);
		 * 
		 * request.setAttribute("empleadoPorNombre", list); RequestDispatcher
		 * requestDispatcher2 = request.getRequestDispatcher("empleadoPorNombre.jsp");
		 * requestDispatcher2.forward(request, response); } else if (sId.equals("dni"))
		 * { doGet(request, response); String sDni = request.getParameter("DNI"); String
		 * sNombre = null; String sLetra = null; byte bAnios = 0; byte bCategoria = 0;
		 * 
		 * Empleado oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
		 * List<Empleado> list = Principal.generalController.getEmpleadoController()
		 * .buscarEmpleadoPorDni(oEmpleado);
		 * 
		 * request.setAttribute("empleadoPorDni", list); RequestDispatcher
		 * requestDispatcher1 = request.getRequestDispatcher("empleadoPorDni.jsp");
		 * requestDispatcher1.forward(request, response); } else if (sId.equals("sexo"))
		 * { doGet(request, response); String sLetra = request.getParameter("sexo");
		 * String sDni = null; String sNombre = null; byte bAnios = 0; byte bCategoria =
		 * 0;
		 * 
		 * Empleado oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
		 * List<Empleado> list = Principal.generalController.getEmpleadoController()
		 * .buscarEmpleadoPorSexo(oEmpleado);
		 * 
		 * request.setAttribute("empleadoPorSexo", list); RequestDispatcher
		 * requestDispatcher1 = request.getRequestDispatcher("empleadoPorSexo.jsp");
		 * requestDispatcher1.forward(request, response); } else if
		 * (sId.equals("categoria")) { doGet(request, response); String bCategoria =
		 * request.getParameter("categoria"); byte bCategoria1 =
		 * Byte.parseByte(bCategoria); String sNombre = null; String sDni = null; String
		 * sLetra = null; byte bAnios = 0;
		 * 
		 * Empleado oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios,
		 * bCategoria1); List<Empleado> list =
		 * Principal.generalController.getEmpleadoController()
		 * .buscarEmpleadoPorCategoria(oEmpleado);
		 * 
		 * request.setAttribute("empleadoPorCategoria", list); RequestDispatcher
		 * requestDispatcher1 =
		 * request.getRequestDispatcher("empleadoPorCategoria.jsp");
		 * requestDispatcher1.forward(request, response); } else if
		 * (sId.equals("aniosTrabajados")) { doGet(request, response); String bAnios =
		 * request.getParameter("anios"); byte bAnios1 = Byte.parseByte(bAnios); String
		 * sNombre = null; String sDni = null; String sLetra = null; Byte bCategoria =
		 * 0;
		 * 
		 * Empleado oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios1,
		 * bCategoria); List<Empleado> list =
		 * Principal.generalController.getEmpleadoController()
		 * .buscarEmpleadoPorAnios(oEmpleado);
		 * 
		 * request.setAttribute("empleadoPorAnios", list); RequestDispatcher
		 * requestDispatcher1 = request.getRequestDispatcher("empleadoPorAnios.jsp");
		 * requestDispatcher1.forward(request, response); } else if
		 * (sId.equals("volver")) { doGet(request, response); RequestDispatcher
		 * requestDispatcher1 = request.getRequestDispatcher("index.jsp");
		 * requestDispatcher1.forward(request, response); }
		 * 
		 * }
		 * 
		 * else if (sOpcion.equals("mostrarSalario")) { doGet(request, response); String
		 * sDni = request.getParameter("DNI"); String sNombre = null; String sLetra =
		 * null; byte bAnios = 0; byte bCategoria = 0;
		 * 
		 * float fSalario =
		 * Principal.generalController.getEmpleadoController().getSalarioDB(sDni);
		 * Empleado oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
		 * List<Empleado> list =
		 * Principal.generalController.getEmpleadoController().buscarEmpleadoPorDni(
		 * oEmpleado);
		 * 
		 * request.setAttribute("mostrarSalario", fSalario);
		 * request.setAttribute("mostrarEmpleado", list); RequestDispatcher
		 * requestDispatcher = request.getRequestDispatcher("tablaSalario1E.jsp");
		 * requestDispatcher.forward(request, response);
		 * 
		 * } else if (sOpcion.equals("volver")) { doGet(request, response);
		 * RequestDispatcher requestDispatcher =
		 * request.getRequestDispatcher("index.jsp"); requestDispatcher.forward(request,
		 * response); }
		 * 
		 * }
		 * 
		 * /* if (sOpcion.equals("entrar")) {
		 * 
		 * List<Empleado> list =
		 * Principal.generalController.getEmpleadoController().mostrarEmpleados();
		 * request.setAttribute("listaEmpleados", list);
		 * 
		 * 
		 * RequestDispatcher dispatcher =
		 * request.getRequestDispatcher("listaEmpleados.jsp");
		 * dispatcher.forward(request, response);
		 * 
		 * }else if (sOpcion.equals("salir")) { RequestDispatcher
		 * requestDispatcher=request.getRequestDispatcher("salida.jsp");
		 * requestDispatcher.forward(request, response); }
		 * 
		 * }
		 */

		/*
		 * public void mostrarDatos(HttpServletRequest request, HttpServletResponse
		 * response) throws ServletException, IOException {
		 * 
		 * List<Empleado> list =
		 * Principal.generalController.getEmpleadoController().mostrarEmpleados();
		 * request.setAttribute("listaEmpleados", list);
		 * 
		 * RequestDispatcher dispatcher =
		 * request.getRequestDispatcher("listaEmpleados.jsp");
		 * dispatcher.forward(request, response); }
		 * 
		 * public void modificarDatos(HttpServletRequest request, HttpServletResponse
		 * response) throws ServletException, IOException { doGet(request, response);
		 * String sId = request.getParameter("id"); if (sId.equals("nombre")) {
		 * RequestDispatcher requestDispatcher =
		 * request.getRequestDispatcher("buscarPorNombre.jsp");
		 * requestDispatcher.forward(request, response); } else if (sId.equals("dni")) {
		 * RequestDispatcher requestDispatcher =
		 * request.getRequestDispatcher("buscarPorDni.jsp");
		 * requestDispatcher.forward(request, response); } else if (sId.equals("sexo"))
		 * { RequestDispatcher requestDispatcher =
		 * request.getRequestDispatcher("buscarPorSexo.jsp");
		 * requestDispatcher.forward(request, response); } else if
		 * (sId.equals("categoria")) { RequestDispatcher requestDispatcher =
		 * request.getRequestDispatcher("buscarPorCategoria.jsp");
		 * requestDispatcher.forward(request, response); } else if
		 * (sId.equals("aniosTrabajados")) { RequestDispatcher requestDispatcher =
		 * request.getRequestDispatcher("buscarPorAnios.jsp");
		 * requestDispatcher.forward(request, response); } else if
		 * (sId.equals("volver")) { RequestDispatcher requestDispatcher =
		 * request.getRequestDispatcher("index.jsp"); requestDispatcher.forward(request,
		 * response); } }
		 * 
		 * public void buscarPorNombre(HttpServletRequest request, HttpServletResponse
		 * response) throws ServletException, IOException { doGet(request, response);
		 * RequestDispatcher requestDispatcher1 =
		 * request.getRequestDispatcher("buscarPorNombre.jsp");
		 * requestDispatcher1.forward(request, response); String sNombre =
		 * request.getParameter("nombre"); String sDni = null; String sLetra = null;
		 * byte bAnios = 0; byte bCategoria = 0;
		 * 
		 * Empleado oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
		 * List<Empleado> list =
		 * Principal.generalController.getEmpleadoController().buscarEmpleadoPorNombre(
		 * oEmpleado);
		 * 
		 * request.setAttribute("empleadoPorNombre", list); RequestDispatcher
		 * requestDispatcher2 = request.getRequestDispatcher("empleadoPorNombre.jsp");
		 * requestDispatcher2.forward(request, response);
		 */ }


