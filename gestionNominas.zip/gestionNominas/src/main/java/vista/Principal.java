package vista;

import controlador.database.GeneralController;

public class Principal {

	public static GeneralController generalController = new GeneralController("esty");

	public static void main(String[] args) {

	}
}
