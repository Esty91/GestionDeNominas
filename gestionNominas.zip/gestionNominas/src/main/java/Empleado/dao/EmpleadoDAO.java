package Empleado.dao;

import java.util.List;

import modelo.Empleado;

public interface EmpleadoDAO {

	List<Empleado> get();

	
}
