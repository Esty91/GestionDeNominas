package Empleado.dao;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import controlador.database.DBconnection;
import modelo.Empleado;


public class EmpleadoDaoImpl implements EmpleadoDAO {

	private static Statement stmt;
	private static ResultSet results;
	
	
	
	
	public List<Empleado> get() {
		
		String sql = "SELECT * FROM EMPLEADO;";
		List<Empleado> list = null;
		Empleado oEmpleado = null;
		
		try (Connection conn = DBconnection.getConnection()) {
			
			stmt = conn.createStatement();
			results = stmt.executeQuery(sql);
			list = new ArrayList<Empleado>();
			
			while (results.next()) {
				String sNombre = null;
				String sDni = null;
				String sLetra = null;
				byte bAnios = 0;
				byte bCategoria = 0;
				oEmpleado = new Empleado(sNombre, sDni, sLetra, bAnios, bCategoria);
				oEmpleado.setsNombre(results.getString(sNombre));
				oEmpleado.setsDni(results.getString(sDni));
				oEmpleado.setcLetra(results.getString(sLetra));
				oEmpleado.setbAnios(results.getByte(bAnios));
				oEmpleado.setbCategoria(results.getByte(bCategoria));
				list.add(oEmpleado);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

}
